//
//  FrontViewController.swift
//  Chapter04-SideBarDIY
//
//  Created by 이재은 on 24/05/2020.
//  Copyright © 2020 Jaeeun. All rights reserved.
//

import UIKit

class FrontViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}

//
//  ViewController.swift
//  Chapter06-HR
//
//  Created by 이재은 on 2020/07/19.
//  Copyright © 2020 Jaeeun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


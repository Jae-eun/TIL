//
//  main.swift
//  Functional_Swift
//
//  Created by 이재은 on 13/01/2020.
//  Copyright © 2020 jaeeun. All rights reserved.
//

import Foundation

typealias Distance = Double

struct Position {
    var x: Double
    var y: Double
}

struct Ship {
    var position: Position
    var firingRange: Distance
    var unsafeRange: Distance
}

extension Position {
    /// 회색 영역에 점이 있는지 확인
    func inRange(range: Distance) -> Bool {
        return sqrt(x * x + y * y) <= range
    }
}

extension Ship {
    /// 다른 함선이 포격 범위에 드는지 확인
    func canEngageShip(target: Ship) -> Bool {
        let dx = target.position.x - position.x
        let dy = target.position.y - position.y
        let targetDistance = sqrt(dx * dx + dy * dy)
        return targetDistance <= firingRange
    }

    func canSafelyEngageShip(target: Ship) -> Bool {
        let dx = target.position.x - position.x
        let dy = target.position.y - position.y
        let targetDistance = sqrt(dx * dx + dy * dy)
        return targetDistance <= firingRange && targetDistance > unsafeRange
    }
}

let day = ["화", "수", "목", "금", "토", "일", "월"]
func whatDayOfTheWeekInJanuary(_ date: Int) -> String {
    return "\(day[date % 7])요일"
}

print(whatDayOfTheWeekInJanuary(30))

let whatDayOfTheWeekInJanuaryClosure = { (date: Int) -> String in
    return "\(day[date % 7])요일입니다~"
}

print(whatDayOfTheWeekInJanuaryClosure(15))

let today = { (month: Int, date: Int) -> String in
  return "오늘은 \(month)월 \(date)일입니다!"
}

print(today(1, 15))

let today2: (Int, Int) -> String = { "오늘은 \($0)월 \($1)일입니다!" }
print(today2(1, 30))

func whatDay(month: Int, date: Int, closure: (Int, Int) -> String) -> String {
    return closure(month, date)
}

print(whatDay(month: 1, date: 20, closure: today))
print(whatDay(month: 1, date: 22, closure: { mon, da in
    return "\(mon)월 \(da)일!!"
}))
print(whatDay(month: 1, date: 25){ "\($0)월 \($1)일~" })

let numbers = [0, 1, 2, 3, 4]

var doubledNumbers = [Int]()
var strings = [String]()

// for-in
for number in numbers {
    doubledNumbers.append(number * 2)
    strings.append("\(number)")
}

// map
doubledNumbers = numbers.map{ $0 * 2 }
strings = numbers.map{ "\($0)" }


let evens = [0, 2, 4, 6, 8]
let odds = [1, 3, 5, 7, 9]
let multiplyTwo: (Int) -> Int = { $0 * 2 }

let doubledEvens = evens.map(multiplyTwo)
let doubledOdds = odds.map(multiplyTwo)


let numbers2 = [0, 1, 2, 3, 4, 5]

let evens2 = numbers2.filter{ $0 % 2 == 0 } // [0, 2, 4]
// map과 filter를 연결하여 사용할 수도 있음
let odds2 = numbers2.map{ $0 + 3 }.filter{ $0 % 2 != 0 } // [3, 5, 7]

let numbers3 = [1, 2, 3]
var sum = numbers3.reduce(10) { $0 + $1 } // 16
